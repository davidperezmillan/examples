package com.davidperezmillan.hamspy.simple;

import com.davidperezmillan.hamspy.simple.frames.MyJToggleButton;

public class DefaultAplicationMainService  {

    public static void main(String[] args) {
        new MyJToggleButton();
	}
	
	
}