package com.davidperezmillan.hamspy.simple.frames;

import com.davidperezmillan.hamspy.simple.components.TextAreaOutputStream;
import com.davidperezmillan.hamspy.simple.threads.impl.MoveMouseThread;
import com.davidperezmillan.hamspy.simple.utils.Logger;
import com.davidperezmillan.hamspy.simple.utils.Version;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.PrintStream;
import java.time.LocalDateTime;
import java.time.LocalTime;


public class MyJToggleButton extends JFrame {
    private static final long serialVersionUID = 1L;

    private JToggleButton btn;
    private JButton btnCleaner;
    private JTextArea txtConsole;
    private MoveMouseThread lT;
    private JToggleButton ts;
    private JTextArea txtTime;
    private JScrollPane scroll;

    private String version = "0.1.0";

    public MyJToggleButton() {
        setTitle(Version.buildTitleToVersion("HamSpy", version));

        GridLayout general = new GridLayout(3, 1);
        FlowLayout firstLayout = new FlowLayout();
        FlowLayout secondLayout = new FlowLayout();

        setLayout(new FlowLayout());
        setJToggleButton();

        setAction();
        setSize(600, 450);
        setLocation(1000, 500);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


    }


    private void setJToggleButton() {

        btn = new JToggleButton("Ready"); // $NON-NLS-1$
        btn.setPreferredSize(new Dimension(200, 20));
        add(btn);


        ts = new JToggleButton("Timer");
        ts.setPreferredSize(new Dimension(100, 20));
        ts.setSelected(true);
        add(ts);
        txtTime = new JTextArea();
        txtTime.setPreferredSize(new Dimension(50, 20));

        // calculate time
        txtTime.setText(calculate());
        add(txtTime);

        txtConsole = new JTextArea(20, 50);

        scroll = new JScrollPane(txtConsole,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        // Now create a new TextAreaOutputStream to write to our JTextArea control and wrap a
        // PrintStream around it to support the println/printf methods.
        PrintStream out = new PrintStream(new TextAreaOutputStream(txtConsole));
        // redirect standard output stream to the TextAreaOutputStream
        // redirect standard error stream to the TextAreaOutputStream
        System.setOut(out);
        System.setErr(out);
        txtConsole.setSize(600, 450);
        txtConsole.setVisible(true);

        add(scroll);


        btnCleaner = new JButton("Cleaner"); // $NON-NLS-1$
        btnCleaner.setPreferredSize(new Dimension(200, 20));
        add(btnCleaner);

    }

    private String calculate() {
        LocalTime now = LocalDateTime.now().toLocalTime();
        String entrega = "8:45";
        String comida = "15:00";
        String salida = "18:00";
        String[] times = {entrega, comida, salida};
        String time = salida;
        for (String t : times) {
            String[] timeSplit = t.split(":");
            if (now.isBefore(LocalTime.of(Integer.parseInt(timeSplit[0]), Integer.parseInt(timeSplit[1])))) {
                time = t;
                return time;
            }
        }
        return time;
    }

    private void setAction() {

        btn.addItemListener(
                new ItemListener() {
                    @Override
                    public void itemStateChanged(ItemEvent eve) {
                        if (btn.isSelected()) {
                            txtConsole.setText("");
                            Logger.print("Clear logs & start");
                            lT = new MoveMouseThread(createTimeApproach(txtTime.getText(), ts.isSelected()), btn);
                            lT.start();
                            btn.setText("Pause");
                        } else {

                            txtTime.setText(calculate());
                            lT.stop();
                            btn.setText("Ready");
                            Logger.print("Stop & regulate time");
                        }
                    }
                });

        btnCleaner.setAction(
                new AbstractAction("Clean") {
                    @Override
                    public void actionPerformed(java.awt.event.ActionEvent e) {
                        txtConsole.setText("");
                        Logger.print("Clear manual logs .... ");
                    }
                });


    }

    private LocalDateTime createTimeApproach(String txtTime, boolean selected) {
        if (!selected) {
            return null;
        }
        try {
            int hour = Integer.parseInt(txtTime.split(":")[0]);
            int minute = Integer.parseInt(txtTime.split(":")[1]);
            return LocalDateTime.of(LocalDateTime.now().getYear(), LocalDateTime.now().getMonth(), LocalDateTime.now().getDayOfMonth(), hour, minute);
        } catch (Exception e) {
            return null;
        }
    }
}
