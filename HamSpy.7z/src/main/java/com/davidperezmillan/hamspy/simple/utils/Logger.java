package com.davidperezmillan.hamspy.simple.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {

    private static final String timeFormat = "HH:mm:ss";
    private static final String dateFormat = "dd/MM/yyyy";
    private static final String dateTimeFormat = dateFormat + " " + timeFormat;

    public static String formatLocalTime(LocalDateTime time) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(timeFormat);
        return time.format(formatter);
    }

    public static String formatLocalDateTime(LocalDateTime localDateTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateTimeFormat);
        return localDateTime.format(formatter);
    }

    public static void print(String text) {
        String dateEvent = formatLocalDateTime(LocalDateTime.now());
        System.out.println("["+dateEvent+"]   --   " + text);
    }

    public static void error(String text) {
        String dateEvent = formatLocalDateTime(LocalDateTime.now());
        System.err.println("["+dateEvent+"]   --   " + text);
    }
}
