package com.davidperezmillan.hamspy.simple.utils;

import com.davidperezmillan.hamspy.simple.DefaultAplicationMainService;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class Version {

    public static String buildTitleToVersion(String name, String version) {
        Version versionClass = new Version();
        String vData = versionClass.getBuildDate();
        return name + " " +  version + " " + vData;
    }

    private String getBuildDate() {
        try {
            File jarFile = new File(DefaultAplicationMainService.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            LocalDateTime f = new Date(jarFile.lastModified()).toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDateTime();
            return f.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        } catch (URISyntaxException e) {
            Logger.error("Error getting build date");
        }
        return "";
    }

}
