package com.davidperezmillan.hamspy.simple.threads.impl;


import com.davidperezmillan.hamspy.simple.utils.Logger;
import javax.swing.*;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Random;

public class MoveMouseThread {

  private static Robot hal;
  private JToggleButton btn;
  private LocalDateTime timeApproach;

  public Thread t =
      new Thread(
          () -> {
            try {
              hal = new Robot();
              Random random = new Random();
              while (!Thread.currentThread().isInterrupted()) {
                LocalDateTime today = LocalDateTime.now();

                if (timeApproach != null){
                  Logger.print("Time Approach: " + Logger.formatLocalTime(timeApproach));
                  if (today.isAfter(timeApproach)) {
                    Logger.print("Time is not yet");
                    Thread.currentThread().interrupt();
                    btn.setText("Ready");
                    btn.setSelected(false);
                    break;
                  }
                }
                int x = random.nextInt(200);
                int y = random.nextInt(1000);

                hal.mouseMove(x, y); // Simula Movimiento

                // click(); // Simula el click del raton
                // keypress("Ancer", true); // Simula presion de teclas

                Logger.print( "Hilo: X: " + x + " Y: " + y);

                hal.mouseMove(400 + x, 200 + y); // Simula Movimiento

                // click(); // Simula el click del raton

                try {
                  Thread.sleep((60 * 1000) * 1); // (Segundo * milisegundo) * minutos
                } catch (InterruptedException e) {
                  // Evitamos que si esta en sleep no lanze excepcion
                  Thread.currentThread().interrupt();
                }
              }
            } catch (AWTException e) {
              Logger.error("Error " + e);
              Thread.currentThread().interrupt();
            }
          });


  public MoveMouseThread(LocalDateTime timeApproach, JToggleButton btn) {
    this.timeApproach = timeApproach;
    this.btn = btn;
  }

  private void click() throws AWTException {
    hal.mousePress(InputEvent.BUTTON1_DOWN_MASK);
    hal.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
  }

  private void keypress(String text, Boolean isDelete) throws AWTException {
    for (char letter : text.toCharArray()) {
      hal.keyPress(KeyEvent.getExtendedKeyCodeForChar(letter));
      if (isDelete) hal.keyPress(KeyEvent.VK_BACK_SPACE);
    }
  }

  public void start() {
    Logger.print("Starting thread");
    t.start();
  }

  public void stop() {
    Logger.print("Stopping thread");
    t.interrupt();
  }



}
